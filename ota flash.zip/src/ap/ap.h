/*
 * ap.h
 *
 *  Created on: May 2, 2025
 *      Author: USER
 */

#ifndef SRC_AP_AP_H_
#define SRC_AP_AP_H_


#include "hw.h"


void ap_init(void);
void ap_main(void);


#endif /* SRC_AP_AP_H_ */
