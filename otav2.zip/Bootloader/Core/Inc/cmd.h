/*
 * cmd.h
 *
 *  Created on: Jun 20, 2025
 *      Author: zvxc3
 */

#ifndef INC_CMD_H_
#define INC_CMD_H_


#include "hw_def.h"

#define CMD_OK      0x0000



#endif /* INC_CMD_H_ */
