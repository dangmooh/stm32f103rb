/*
 * def.h
 *
 *  Created on: Jun 20, 2025
 *      Author: zvxc3
 */

#ifndef INC_DEF_H_
#define INC_DEF_H_



#include <stdint.h>
#include <stdbool.h>
#include <string.h>


#include "err_code.h"


#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))


#define MAGIC_NUMBER              0x5555AAAA
#define FLASH_MAGIC_NUMBER        0x5555AAAA

#define VERSION_MAGIC_NUMBER      0x56455220    // "VER "
#define TAG_MAGIC_NUMBER          0x54414720    // "TAG "
/*
typedef union
{
  uint8_t  u8Data[4];
  uint16_t u16Data[2];
  uint32_t u32Data;

  int8_t   s8Data[4];
  int16_t  s16Data[2];
  int32_t  s32Data;

  uint8_t  u8D;
  uint16_t u16D;
  uint32_t u32D;

  int8_t   s8D;
  int16_t  s16D;
  int32_t  s32D;
} data_t;*/


typedef struct
{
  uint32_t magic_number;
  char     version_str[32];
  char     name_str[32];
  uint32_t firm_addr;
} firm_ver_t;

typedef struct
{
  uint32_t magic_number;
  uint32_t fw_addr;
  uint32_t fw_size;
  uint32_t fw_crc;

  uint32_t tag_crc;
} firm_tag_t;




#endif /* INC_DEF_H_ */
