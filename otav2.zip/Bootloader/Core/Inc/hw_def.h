/*
 * hw_def.h
 *
 *  Created on: Jun 20, 2025
 *      Author: zvxc3
 */

#ifndef INC_HW_DEF_H_
#define INC_HW_DEF_H_


#include "main.h"
#include "def.h"


#define FLASH_SIZE_TAG              0x400
#define FLASH_SIZE_VEC              0x400
#define FLASH_SIZE_VER              0x400
#define FLASH_SIZE_FIRM             (384*1024)

#define FLASH_ADDR_BOOT             0x08000000
#define FLASH_ADDR_UPDATE

/* USER CODE BEGIN PD */
#define APPLICATION_A_ADDRESS 0x8008000 /*Partition A address */
#define APPLICATION_B_ADDRESS 0x8014000 /*Partition B address */


#define BOOT_FLAG_BOOT 0x00
#define BOOT_FLAG_A 0x01 /* Partition A activate */
#define BOOT_FLAG_B 0x02 /* Partition B activate */




#endif /* INC_HW_DEF_H_ */
