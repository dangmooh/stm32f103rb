/*
 * reset.c
 *
 *  Created on: Jun 18, 2025
 *      Author: USER
 */


#include "reset.h"


static const char *mode_bit_str[] =
  {
    "MODE_BIT_BOOT",
    "MODE_BIT_UPDATE",
  };

static bool is_init = false;
static uint32_t boot_mode = 0;
#define BOOT_FLAG_ADDR BKP->DR1 /*Boot flag address*/


bool resetInit(void)
{
  bool ret;


  uint32_t boot_flag = BOOT_FLAG_ADDR;
  BOOT_FLAG_ADDR = 0;

  is_init = true;

  ret = is_init;
  return ret;
}

void resetToBoot(void)
{
  resetSetBootMode(1<<MODE_BIT_BOOT);
  resetToReset();
}

void resetToReset(void)
{
  HAL_NVIC_SystemReset();
}

void resetSetBootMode(uint32_t mode)
{
  boot_mode = mode;
  rtcSetReg(HW_RTC_BOOT_MODE, mode);
}

uint32_t resetGetBootMode(void)
{
  return boot_mode;
}
