/*
 * boot.h
 *
 *  Created on: Jun 18, 2025
 *      Author: USER
 */

#ifndef INC_BOOT_H_
#define INC_BOOT_H_



uint16_t bootVerifyUpdate(void);
uint16_t bootVerifyFirm(void);
uint16_t bootUpdateFirm(void);
uint16_t bootUpdateFirmFromFile(const char *file_name);
uint16_t bootJumpFirm(void);

#endif /* INC_BOOT_H_ */
