/*
 * ap.h
 *
 *  Created on: Feb 9, 2025
 *      Author: zvxc3
 */

#ifndef SRC_AP_AP_H_
#define SRC_AP_AP_H_

#include "hw.h"


void apInit(void);
void apMain(void);


#endif /* SRC_AP_AP_H_ */
