/*
 * main.c
 *
 *  Created on: Feb 9, 2025
 *      Author: zvxc3
 */


#include "main.h"





int main(void)
{
  hwInit();
  apInit();

  apMain();

  return 0;
}
